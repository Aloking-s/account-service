package com.mavericsystems.accountservice.Consumer;



import org.apache.catalina.connector.Response;

public class FeignConsumerErrorDecoder {

   /* @Override public Exception decode(String methodKey , Response response){

        byte[] bodyData = new byte[0];
        System.out.println(response);
        try{
            bodyData = Util.toByteArray(response.body().asInputStream());
        }*/



}
