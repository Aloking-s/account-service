package com.mavericsystems.accountservice.Enums;

public enum Currency {
    INR, DOLLAR, EURO

}
