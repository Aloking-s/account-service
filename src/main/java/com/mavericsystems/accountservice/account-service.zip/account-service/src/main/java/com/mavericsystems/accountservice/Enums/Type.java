package com.mavericsystems.accountservice.Enums;

public enum Type {
    CURRENT , SAVINGS;
}
